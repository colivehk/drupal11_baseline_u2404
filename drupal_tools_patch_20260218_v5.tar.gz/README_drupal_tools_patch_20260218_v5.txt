Patch v5 (2026-02-18)

What it fixes
- drupal_optimizerV0.2.5.2 could generate an invalid /sites/default/settings.statekeeper.php, causing:
    ParseError: syntax error, unexpected token "\\" ...
  Root cause: the Redis include block written into settings.statekeeper.php contained "\$app_root" / "\$site_path".

Changes
- drupal_optimizerV0.2.5.3.sh
  - Writes the Redis include block as valid PHP:
      $redis_settings = $app_root . '/' . $site_path . '/settings.redis.php';
  - Runs ensure_statekeeper_file after editing settings.statekeeper.php (normalize + php -l lint + auto-repair fallback)

- drupal_statekeeperV0.1.8.sh
  - Unchanged in this patch (included for convenience).

How to use
1) Extract this tar.gz into your scripts directory (e.g. /home/ubuntu).
2) Use drupal_optimizerV0.2.5.3.sh instead of V0.2.5.2.

If Drush is already broken (bootstrap ParseError)
- Temporarily repair the file so you can run Drush again:
    sudo perl -pi -e 's/\\\$(app_root|site_path)/\$$1/g' /var/www/drupal/web/sites/default/settings.statekeeper.php
  Then:
    cd /var/www/drupal && ./vendor/bin/drush --uri=http://YOUR_IP cr
