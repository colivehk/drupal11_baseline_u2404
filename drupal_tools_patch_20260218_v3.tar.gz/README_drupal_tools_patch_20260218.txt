drupal-tools patch (2026-02-18)

Included:
- drupal_optimizerV0.2.5.2.sh (based on your V0.2.5.1)
- drupal_statekeeperV0.1.8.sh (based on your V0.1.7)

Key fixes:
1) settings.statekeeper.php "syntax error, unexpected token <" protection:
   - Optimizer now normalizes settings.statekeeper.php so it contains exactly ONE opening '<?php' tag.
   - Runs PHP lint (php -l) and auto-backs up + writes a safe placeholder if lint fails.

2) Optimizer Redis include block idempotency:
   - Removes ALL existing '# BEGIN/END DRUPAL_OPTIMIZER_REDIS_INCLUDE' blocks (even if formatting differs),
     then appends exactly one canonical block (prevents duplicates).

3) Safer include in settings.php:
   - Both scripts now write a guarded include block for settings.statekeeper.php
     (only include if header looks valid and contains a single '<?php').

Notes:
- Your cron lock /run/drupal-cron/drupal-cron.lock improvements from V0.2.5.1 are kept.
